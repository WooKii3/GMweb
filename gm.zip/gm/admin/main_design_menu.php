							<tr>
								<td colspan="2">
									<table width="750" border="0" cellspacing="1" cellpadding="0" height="60" align='center' bgcolor='cdcdcd'>
										<tr>
											<td bgcolor='fafafa' align="center"><input class="box" value="��������" style="background-color:#ECF2AD; text-align:center; height:18; cursor:pointer" size="8" readonly onclick="design_view()"></td>
											<td bgcolor='fafafa'>
												<table width="650" border="0" cellspacing="0" cellpadding="0" height="60" align='center'>
													<tr align="center">
														<td><a href="design.php"><img src="image/design_m01.gif" width="58" height="19" border="0"></a></td>
														<td><a href="design_a.php"><img src="image/design_m02.gif" width="40" height="19" border="0"></a></td>
														<td><a href="design_b.php"><img src="image/design_m03.gif" width="40" height="19" border="0"></a></td>
														<td><a href="design_b1.php"><img src="image/design_m03_1.gif" width="40" height="19" border="0"></a></td>
														<td><a href="design_c.php"><img src="image/design_m04.gif" width="40" height="19" border="0"></a></td>
													</tr>
													<tr align="center">
														<td><a href="design_d.php"><img src="image/design_m05.gif" width="40" height="19" border="0"></a></td>
														<td><a href="design_e.php"><img src="image/design_m06.gif" width="40" height="19" border="0"></a></td>
														<td><a href="design_f.php"><img src="image/design_m07.gif" width="40" height="19" border="0"></a></td>
														<td><a href="design_g.php"><img src="image/design_m08.gif" width="40" height="19" border="0"></a></td>
														<td>&nbsp;</td>
													</tr>
												</table>
											</td>
										</tr>
									</table>
								</td>
							</tr>