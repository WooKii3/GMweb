							<tr>
								<td colspan="2">
									<table width="550" border="0" cellspacing="0" cellpadding="0" background="image/design_bg0.gif" height="30" align='center'>
										<tr>
											<td width="70">&nbsp;</td>
											<td width="80"> <div align="center"><a href="design_good.php"><img src="image/design_m01.gif" width="58" height="19" border="0"></a></div></td>
											<td width="65"> <div align="center"><a href="design_good_a.php"><img src="image/design_m02.gif" width="40" height="19" border="0"></a></div></td>
											<td width="65"> <div align="center"><a href="design_good_b.php"><img src="image/design_m03.gif" width="40" height="19" border="0"></a></div></td>
											<td width="65">&nbsp;</td>
										</tr>
									</table>
								</td>
							</tr>